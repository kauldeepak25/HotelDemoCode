CREATE TABLE CUSTOMER (  
customer_id INT AUTO_INCREMENT  PRIMARY KEY,  
customer_name VARCHAR(50) NOT NULL,
customer_age INT NOT NULL,  
customer_address VARCHAR(100) NOT NULL,
customer_acc_type VARCHAR(50) NOT NULL
); 