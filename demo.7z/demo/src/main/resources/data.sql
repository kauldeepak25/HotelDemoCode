INSERT INTO CUSTOMER VALUES (11,'Rahul', 30,'Rajinder Nagar, New Delhi','saving');
INSERT INTO CUSTOMER VALUES (12,'Vijay', 34,'Pitampura, New Delhi','checking');
INSERT INTO CUSTOMER VALUES (13,'Raj', 45,'Bandra, Maharastra','saving & checking'); 
INSERT INTO CUSTOMER VALUES (14,'Ajay', 21,'Chandigarh, Punjab','checking');          