INSERT INTO CUSTOMER VALUES (11,'Marriott Inc','NYC',);
INSERT INTO CUSTOMER VALUES (12,'IHG international','New Delhi',);
INSERT INTO CUSTOMER VALUES (13,'America stay Inc','Gaithersburg',);
INSERT INTO CUSTOMER VALUES (14,'Hyatt International','London',);      