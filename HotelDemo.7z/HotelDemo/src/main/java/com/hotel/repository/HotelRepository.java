package com.hotel.repository;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.hotel.entity.Hotel;



public interface HotelRepository extends PagingAndSortingRepository<Hotel, Integer> {
}