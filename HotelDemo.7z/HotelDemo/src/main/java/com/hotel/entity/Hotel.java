/**
 * 
 */
package com.hotel.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author kauld
 *
 */
@Entity
@Table
public class Hotel {

	@Id
	@Column(name = "hotel_id")
	private int id;

	@Column(name = "hotel_name")
	private String hotelName;

	@Column(name = "hotel_adress")
	private String hotel_address;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getHotelName() {
		return hotelName;
	}

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}

	public String getHotel_address() {
		return hotel_address;
	}

	public void setHotel_address(String hotel_address) {
		this.hotel_address = hotel_address;
	}

}
